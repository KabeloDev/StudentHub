﻿namespace ASPNETCore_DB
{
    public class WebConstants
    {
        public static string ImagePath = @"\images\";
    }
}
